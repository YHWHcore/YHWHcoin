This is a textarea for a PULL REQUEST about griddb/griddb_nosql repository.

**REMOVE THE TEXT ABOVE BEFORE CREATING THE PULL REQUEST**