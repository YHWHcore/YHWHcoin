/*
   Copyright (c) 2017 TOSHIBA Digital Solutions Corporation

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package com.toshiba.mwcloud.gs.experimental;


public enum ContainerAttribute {

	BASE(0x00000000),

	BASE_SYSTEM(0x00000001),

	SINGLE(0x00000010),

	SINGLE_SYSTEM(0x00000011),

	SINGLE_SEMI_PERMANENT_SYSTEM(0x00000015),

	LARGE(0x00000020),

	SUB(0x00000030),

	VIEW(0x00000040)
	;

	private int flag;

	private ContainerAttribute(int flag) {
		this.flag = flag;
	}

	public int flag() {
		return this.flag;
	}

	public static ContainerAttribute getAttribute(int flag) {

		for (ContainerAttribute attribute : values()) {
			if (attribute.flag() == flag) {
				return attribute;
			}
		}
		return null;
	}

}
